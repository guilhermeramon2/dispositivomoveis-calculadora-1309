import 'package:flutter/material.dart';

void main() {
  runApp(const CalculadoraApp());
}

class CalculadoraApp extends StatelessWidget {
  const CalculadoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculadora',
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: const CalculadoraPage(),
    );
  }
}

class CalculadoraPage extends StatefulWidget {
  const CalculadoraPage({super.key});

  @override
  State<CalculadoraPage> createState() => _CalculadoraPageState();
}

class _CalculadoraPageState extends State<CalculadoraPage> {
  bool darkMode = true;

  String display = '0';
  String expression = '';

  double? firstNumber;
  String? operator;
  bool waitingForSecondNumber = false;

  static const Color operationColor = Color(0xFF4657F5);

  Color get backgroundColor =>
      darkMode ? const Color(0xFF121117) : const Color(0xFFF1F7F8);

  Color get numberButtonColor =>
      darkMode ? const Color(0xFF29282F) : Colors.white;

  Color get functionButtonColor =>
      darkMode ? const Color(0xFF4A4B57) : const Color(0xFFD0D4D8);

  Color get textColor => darkMode ? Colors.white : Colors.black;

  Color get secondaryTextColor =>
      darkMode ? const Color(0xFF77777F) : const Color(0xFF858585);

  void pressNumber(String number) {
    setState(() {
      if (waitingForSecondNumber) {
        display = number;
        waitingForSecondNumber = false;
      } else if (display == '0') {
        display = number;
      } else {
        display += number;
      }
    });
  }

  void pressDecimal() {
    setState(() {
      if (waitingForSecondNumber) {
        display = '0.';
        waitingForSecondNumber = false;
      } else if (!display.contains('.')) {
        display += '.';
      }
    });
  }

  void pressClear() {
    setState(() {
      display = '0';
      expression = '';
      firstNumber = null;
      operator = null;
      waitingForSecondNumber = false;
    });
  }

  void pressBackspace() {
    setState(() {
      if (display.length > 1) {
        display = display.substring(0, display.length - 1);
      } else {
        display = '0';
      }
    });
  }

  void pressPlusMinus() {
    setState(() {
      if (display != '0') {
        if (display.startsWith('-')) {
          display = display.substring(1);
        } else {
          display = '-$display';
        }
      }
    });
  }

  void pressPercent() {
    setState(() {
      final number = double.tryParse(display) ?? 0;
      display = formatNumber(number / 100);
    });
  }

  void pressOperator(String newOperator) {
    setState(() {
      double currentNumber = double.tryParse(display) ?? 0;

      if (firstNumber != null &&
          operator != null &&
          !waitingForSecondNumber) {
        calculate();
        currentNumber = double.tryParse(display) ?? 0;
      }

      firstNumber = currentNumber;
      operator = newOperator;
      waitingForSecondNumber = true;

      expression = '${formatNumber(currentNumber)} $newOperator';
    });
  }

  void calculate() {
    if (firstNumber == null || operator == null) {
      return;
    }

    final secondNumber = double.tryParse(display) ?? 0;
    double result = 0;

    switch (operator) {
      case '+':
        result = firstNumber! + secondNumber;
        break;

      case '-':
        result = firstNumber! - secondNumber;
        break;

      case '×':
        result = firstNumber! * secondNumber;
        break;

      case '÷':
        if (secondNumber == 0) {
          display = 'Erro';
          firstNumber = null;
          operator = null;
          expression = '';
          return;
        }

        result = firstNumber! / secondNumber;
        break;
    }

    expression =
        '${formatNumber(firstNumber!)} $operator ${formatNumber(secondNumber)}';

    display = formatNumber(result);

    firstNumber = null;
    operator = null;
    waitingForSecondNumber = true;
  }

  String formatNumber(double number) {
    if (number == number.roundToDouble()) {
      return number.toInt().toString();
    }

    String result = number.toStringAsFixed(10);

    result = result.replaceFirst(RegExp(r'0+$'), '');
    result = result.replaceFirst(RegExp(r'\.$'), '');

    return result;
  }

  Widget calculatorButton(
    String text, {
    required VoidCallback onPressed,
    bool operation = false,
    bool function = false,
  }) {
    Color background;

    if (operation) {
      background = operationColor;
    } else if (function) {
      background = functionButtonColor;
    } else {
      background = numberButtonColor;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(24),
          ),
          alignment: Alignment.center,
          child: Text(
            text,
            style: TextStyle(
              color: operation ? Colors.white : textColor,
              fontSize: 27,
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Proporção aproximada de uma tela de celular
            const double phoneWidth = 390;
            const double phoneHeight = 844;

            double width = constraints.maxWidth;
            double height = constraints.maxHeight;

            // Mantém a proporção de celular
            double calculatorWidth = width;
            double calculatorHeight =
                calculatorWidth * phoneHeight / phoneWidth;

            if (calculatorHeight > height) {
              calculatorHeight = height;
              calculatorWidth =
                  calculatorHeight * phoneWidth / phoneHeight;
            }

            // Em telas grandes, não deixa a calculadora ficar gigante
            if (calculatorWidth > phoneWidth) {
              calculatorWidth = phoneWidth;
              calculatorHeight = phoneHeight;

              if (calculatorHeight > height) {
                calculatorHeight = height;
                calculatorWidth =
                    calculatorHeight * phoneWidth / phoneHeight;
              }
            }

            return Center(
              child: SizedBox(
                width: calculatorWidth,
                height: calculatorHeight,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25),
                  child: Column(
                    children: [
                      const SizedBox(height: 15),

                      // Botão de tema
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            darkMode = !darkMode;
                          });
                        },
                        child: Container(
                          width: 82,
                          height: 40,
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: darkMode
                                ? const Color(0xFF29282F)
                                : Colors.white,
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceAround,
                            children: [
                              Icon(
                                Icons.wb_sunny_outlined,
                                color: !darkMode
                                    ? operationColor
                                    : const Color(0xFF77777F),
                                size: 22,
                              ),
                              Icon(
                                Icons.nightlight_outlined,
                                color: darkMode
                                    ? operationColor
                                    : const Color(0xFF77777F),
                                size: 22,
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 25),

                      // Expressão
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          expression,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: secondaryTextColor,
                            fontSize: 22,
                          ),
                        ),
                      ),

                      const SizedBox(height: 5),

                      // Resultado
                      Align(
                        alignment: Alignment.centerRight,
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            display,
                            style: TextStyle(
                              color: textColor,
                              fontSize: 58,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 15),

                      // Botões
                      Expanded(
                        child: GridView.count(
                          crossAxisCount: 4,
                          crossAxisSpacing: 9,
                          mainAxisSpacing: 9,
                          childAspectRatio: 1,
                          physics:
                              const NeverScrollableScrollPhysics(),
                          children: [
                            calculatorButton(
                              'C',
                              function: true,
                              onPressed: pressClear,
                            ),
                            calculatorButton(
                              '+/-',
                              function: true,
                              onPressed: pressPlusMinus,
                            ),
                            calculatorButton(
                              '%',
                              function: true,
                              onPressed: pressPercent,
                            ),
                            calculatorButton(
                              '÷',
                              operation: true,
                              onPressed: () => pressOperator('÷'),
                            ),

                            calculatorButton(
                              '7',
                              onPressed: () => pressNumber('7'),
                            ),
                            calculatorButton(
                              '8',
                              onPressed: () => pressNumber('8'),
                            ),
                            calculatorButton(
                              '9',
                              onPressed: () => pressNumber('9'),
                            ),
                            calculatorButton(
                              '×',
                              operation: true,
                              onPressed: () => pressOperator('×'),
                            ),

                            calculatorButton(
                              '4',
                              onPressed: () => pressNumber('4'),
                            ),
                            calculatorButton(
                              '5',
                              onPressed: () => pressNumber('5'),
                            ),
                            calculatorButton(
                              '6',
                              onPressed: () => pressNumber('6'),
                            ),
                            calculatorButton(
                              '-',
                              operation: true,
                              onPressed: () => pressOperator('-'),
                            ),

                            calculatorButton(
                              '1',
                              onPressed: () => pressNumber('1'),
                            ),
                            calculatorButton(
                              '2',
                              onPressed: () => pressNumber('2'),
                            ),
                            calculatorButton(
                              '3',
                              onPressed: () => pressNumber('3'),
                            ),
                            calculatorButton(
                              '+',
                              operation: true,
                              onPressed: () => pressOperator('+'),
                            ),

                            calculatorButton(
                              '.',
                              onPressed: pressDecimal,
                            ),
                            calculatorButton(
                              '0',
                              onPressed: () => pressNumber('0'),
                            ),
                            calculatorButton(
                              '⌫',
                              function: true,
                              onPressed: pressBackspace,
                            ),
                            calculatorButton(
                              '=',
                              operation: true,
                              onPressed: () {
                                setState(() {
                                  calculate();
                                });
                              },
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}